import React from 'react'
import mapa from './mapa.png'

function Mapa() {
    return <div className="row">
        <p>Lo aprendi en Digital House</p>
        <img src={mapa} width="500px" />
    </div>
}

export default Mapa